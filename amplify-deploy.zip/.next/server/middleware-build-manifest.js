globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/cbd55ab9639e1e66.js",
    "static/chunks/aa0a7c5c022cbeb9.js",
    "static/chunks/cc759f7c2413b7ff.js",
    "static/chunks/4dd28bc3f722184a.js",
    "static/chunks/turbopack-492cd776fed59e0e.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];