module.exports=[45097,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_blog_getting-started-nextjs-15_page_actions_f7e9f1b0.js.map