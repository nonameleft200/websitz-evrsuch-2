module.exports=[31134,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portfolio_page_actions_224c57fe.js.map